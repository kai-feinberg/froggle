#include "controller.hxx"

int
main()
{
    Model model;

    Controller().run();

    return 0;
}
